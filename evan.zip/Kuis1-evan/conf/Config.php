<?php
define("DB_HOST","localhost");
define("DB_USER","id7716527_evan");
define("DB_PASSWORD","evan123");
define("DB_NAME","id7716527_db_evan");

// echo DB_HOST;
